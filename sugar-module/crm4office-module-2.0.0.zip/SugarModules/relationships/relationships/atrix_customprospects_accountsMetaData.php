<?php
// created: 2010-06-25 14:45:49
$dictionary["atrix_customprospects_accounts"] = array (
  'true_relationship_type' => 'one-to-one',
  'relationships' => 
  array (
    'atrix_customprospects_accounts' => 
    array (
      'lhs_module' => 'ATRIX_CustomProspects',
      'lhs_table' => 'atrix_customprospects',
      'lhs_key' => 'id',
      'rhs_module' => 'Accounts',
      'rhs_table' => 'accounts',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'atrix_custocts_accounts_c',
      'join_key_lhs' => 'atrix_cust09c0ospects_ida',
      'join_key_rhs' => 'atrix_cust188eccounts_idb',
    ),
  ),
  'table' => 'atrix_custocts_accounts_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'atrix_cust09c0ospects_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'atrix_cust188eccounts_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'atrix_custopects_accountsspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'atrix_custopects_accounts_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'atrix_cust09c0ospects_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'atrix_custopects_accounts_idb2',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'atrix_cust188eccounts_idb',
      ),
    ),
  ),
);
?>
