<?php
// created: 2010-04-04 18:19:38
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-04-04 18:19:38
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust188eccounts_idb',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2010-04-04 18:19:38
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_cust188eccounts_idb"] = array (
  'name' => 'atrix_cust188eccounts_idb',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-05-31 17:43:10
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-05-31 17:43:10
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust188eccounts_idb',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2010-05-31 17:43:10
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_cust188eccounts_idb"] = array (
  'name' => 'atrix_cust188eccounts_idb',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-05-31 22:20:32
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-05-31 22:20:32
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust188eccounts_idb',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2010-05-31 22:20:32
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_cust188eccounts_idb"] = array (
  'name' => 'atrix_cust188eccounts_idb',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 00:02:00
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 00:02:00
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust188eccounts_idb',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-01 00:02:00
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_cust188eccounts_idb"] = array (
  'name' => 'atrix_cust188eccounts_idb',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 00:29:09
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 00:29:09
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust188eccounts_idb',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-01 00:29:09
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_cust188eccounts_idb"] = array (
  'name' => 'atrix_cust188eccounts_idb',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 00:34:50
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 00:34:50
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust188eccounts_idb',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-01 00:34:50
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_cust188eccounts_idb"] = array (
  'name' => 'atrix_cust188eccounts_idb',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 01:26:24
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 01:26:24
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust188eccounts_idb',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-01 01:26:24
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_cust188eccounts_idb"] = array (
  'name' => 'atrix_cust188eccounts_idb',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 22:29:40
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 22:29:40
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust188eccounts_idb',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-01 22:29:40
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_cust188eccounts_idb"] = array (
  'name' => 'atrix_cust188eccounts_idb',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-24 22:44:55
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-24 22:44:55
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust188eccounts_idb',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-24 22:44:55
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_cust188eccounts_idb"] = array (
  'name' => 'atrix_cust188eccounts_idb',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-25 12:05:31
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-25 12:05:31
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust188eccounts_idb',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-25 12:05:31
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_cust188eccounts_idb"] = array (
  'name' => 'atrix_cust188eccounts_idb',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-25 12:08:08
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-25 12:08:08
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust188eccounts_idb',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-25 12:08:08
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_cust188eccounts_idb"] = array (
  'name' => 'atrix_cust188eccounts_idb',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-25 14:45:49
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-25 14:45:49
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust188eccounts_idb',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-25 14:45:49
$dictionary["ATRIX_CustomProspects"]["fields"]["atrix_cust188eccounts_idb"] = array (
  'name' => 'atrix_cust188eccounts_idb',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
