<?php
// created: 2010-04-04 18:19:38
$dictionary["Account"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-04-04 18:19:38
$dictionary["Account"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ATRIX_CUSTOMPROSPECTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust09c0ospects_ida',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'atrix_customprospects',
  'module' => 'ATRIX_CustomProspects',
  'rname' => 'name',
);
?>
<?php
// created: 2010-04-04 18:19:38
$dictionary["Account"]["fields"]["atrix_cust09c0ospects_ida"] = array (
  'name' => 'atrix_cust09c0ospects_ida',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-05-31 17:43:10
$dictionary["Account"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-05-31 17:43:10
$dictionary["Account"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ATRIX_CUSTOMPROSPECTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust09c0ospects_ida',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'prospect_lists_prospects',
  'module' => 'ATRIX_CustomProspects',
  'rname' => 'name',
);
?>
<?php
// created: 2010-05-31 17:43:10
$dictionary["Account"]["fields"]["atrix_cust09c0ospects_ida"] = array (
  'name' => 'atrix_cust09c0ospects_ida',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-05-31 22:20:31
$dictionary["Account"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-05-31 22:20:32
$dictionary["Account"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ATRIX_CUSTOMPROSPECTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust09c0ospects_ida',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'atrix_customprospects',
  'module' => 'ATRIX_CustomProspects',
  'rname' => 'name',
);
?>
<?php
// created: 2010-05-31 22:20:32
$dictionary["Account"]["fields"]["atrix_cust09c0ospects_ida"] = array (
  'name' => 'atrix_cust09c0ospects_ida',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 00:02:00
$dictionary["Account"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 00:02:00
$dictionary["Account"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ATRIX_CUSTOMPROSPECTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust09c0ospects_ida',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'prospect_lists_prospects',
  'module' => 'ATRIX_CustomProspects',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-01 00:02:00
$dictionary["Account"]["fields"]["atrix_cust09c0ospects_ida"] = array (
  'name' => 'atrix_cust09c0ospects_ida',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 00:29:09
$dictionary["Account"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 00:29:09
$dictionary["Account"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ATRIX_CUSTOMPROSPECTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust09c0ospects_ida',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'prospect_lists_prospects',
  'module' => 'ATRIX_CustomProspects',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-01 00:29:09
$dictionary["Account"]["fields"]["atrix_cust09c0ospects_ida"] = array (
  'name' => 'atrix_cust09c0ospects_ida',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 00:34:50
$dictionary["Account"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 00:34:50
$dictionary["Account"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ATRIX_CUSTOMPROSPECTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust09c0ospects_ida',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'prospect_lists_prospects',
  'module' => 'ATRIX_CustomProspects',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-01 00:34:50
$dictionary["Account"]["fields"]["atrix_cust09c0ospects_ida"] = array (
  'name' => 'atrix_cust09c0ospects_ida',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 01:26:23
$dictionary["Account"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 01:26:23
$dictionary["Account"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ATRIX_CUSTOMPROSPECTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust09c0ospects_ida',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'prospect_lists_prospects',
  'module' => 'ATRIX_CustomProspects',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-01 01:26:23
$dictionary["Account"]["fields"]["atrix_cust09c0ospects_ida"] = array (
  'name' => 'atrix_cust09c0ospects_ida',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 22:29:40
$dictionary["Account"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-01 22:29:40
$dictionary["Account"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ATRIX_CUSTOMPROSPECTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust09c0ospects_ida',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'prospect_lists_prospects',
  'module' => 'ATRIX_CustomProspects',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-01 22:29:40
$dictionary["Account"]["fields"]["atrix_cust09c0ospects_ida"] = array (
  'name' => 'atrix_cust09c0ospects_ida',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-24 22:44:55
$dictionary["Account"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-24 22:44:55
$dictionary["Account"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ATRIX_CUSTOMPROSPECTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust09c0ospects_ida',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'atrix_customprospects',
  'module' => 'ATRIX_CustomProspects',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-24 22:44:55
$dictionary["Account"]["fields"]["atrix_cust09c0ospects_ida"] = array (
  'name' => 'atrix_cust09c0ospects_ida',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-25 12:05:31
$dictionary["Account"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-25 12:05:31
$dictionary["Account"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ATRIX_CUSTOMPROSPECTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust09c0ospects_ida',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'atrix_customprospects',
  'module' => 'ATRIX_CustomProspects',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-25 12:05:31
$dictionary["Account"]["fields"]["atrix_cust09c0ospects_ida"] = array (
  'name' => 'atrix_cust09c0ospects_ida',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-25 12:08:08
$dictionary["Account"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-25 12:08:08
$dictionary["Account"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ATRIX_CUSTOMPROSPECTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust09c0ospects_ida',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'atrix_customprospects',
  'module' => 'ATRIX_CustomProspects',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-25 12:08:08
$dictionary["Account"]["fields"]["atrix_cust09c0ospects_ida"] = array (
  'name' => 'atrix_cust09c0ospects_ida',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-25 14:45:49
$dictionary["Account"]["fields"]["atrix_customprospects_accounts"] = array (
  'name' => 'atrix_customprospects_accounts',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-06-25 14:45:49
$dictionary["Account"]["fields"]["atrix_customprospects_accounts_name"] = array (
  'name' => 'atrix_customprospects_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ATRIX_CUSTOMPROSPECTS_ACCOUNTS_FROM_ATRIX_CUSTOMPROSPECTS_TITLE',
  'save' => true,
  'id_name' => 'atrix_cust09c0ospects_ida',
  'link' => 'atrix_customprospects_accounts',
  'table' => 'atrix_customprospects',
  'module' => 'ATRIX_CustomProspects',
  'rname' => 'name',
);
?>
<?php
// created: 2010-06-25 14:45:49
$dictionary["Account"]["fields"]["atrix_cust09c0ospects_ida"] = array (
  'name' => 'atrix_cust09c0ospects_ida',
  'type' => 'link',
  'relationship' => 'atrix_customprospects_accounts',
  'source' => 'non-db',
);
?>
