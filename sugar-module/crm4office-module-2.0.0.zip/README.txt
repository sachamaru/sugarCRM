CRM4Office Module for SugarCRM

This module is used by the OpenOffice plugin: 
CRM4Office - OpenOffice Extension for SugarCRM.
You can download the extension from the following
URL:
   http://www.openatrix.com/downloads

After installing the module, it helps the OpenOffice
plugin/extension to perform Mail Merge using SugarCRM
Target Lists.

Why should I use Target Lists?
Target Lists in SugarCRM help you in combining both
Contacts and Leads into a single list and easy to track.
Several firms use Target Lists for selective campaigns
using Mails/Letters.

Can I use this module for my own SOAP API calls?
Yes, this module is provided as is. And you can use
this module in your own or 3rd party applications.

How does this module work?
Like any other module (Leads, Contacts, Projects, etc.,)
You can make queries on Target Lists based on the
prospect_list_id.

for example:
   To get All entries (Leads and Contacts) associated with
   the Target List id: 8fe1394b-d9f1-1921-93f9-4c58ed2c0e63
   The query data to send would be as follows:
   
   p.prospect_list_id = '8fe1394b-d9f1-1921-93f9-4c58ed2c0e63'
   -----------------------------------------------------------
   
   **Replase ${SESSION_ID} with a valid session_id in the SOAP Call.

   The corresponding SOAP Request would be as follows:

   SOAP URL: http://server/sugarcrm/soap.php
   SOAP Action: /get_entry_list
   POST XML:

<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema"  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
   <soapenv:Body>
          <ns1:get_entry_list soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:ns1="http://www.sugarcrm.com/sugarcrm">
                   <session xsi:type="xsd:string">${SESSION_ID}</session>
                   <module_name xsi:type="xsd:string">ATRIX_CustomProspects</module_name>
                   <query xsi:type="xsd:string">p.prospect_list_id = '8fe1394b-d9f1-1921-93f9-4c58ed2c0e63'</query>
                   <order_by xsi:type="xsd:string"></order_by>
                   <offset href="#id0"/>

                  <select_fields soapenc:arrayType="xsd:string[0]" xsi:type="soapenc:Array" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/">
                 </select_fields>
                 <max_results href="#id1"/>
                 <deleted href="#id2"/>
         </ns1:get_entry_list>
         <multiRef id="id2" soapenc:root="0" soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xsi:type="xsd:int"  xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/">0</multiRef>
         <multiRef id="id1" soapenc:root="0" soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xsi:type="xsd:int"  xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/">2000</multiRef>
         <multiRef id="id0" soapenc:root="0" soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xsi:type="xsd:int"  xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/">0</multiRef>
   </soapenv:Body>
</soapenv:Envelope>
      