# This is the sql query that is run to fetch the
#  records from the database for a given Target List Name 
#  also know as ProspectList.
# You can use this to see if your Target Lists are getting
#  records as expect.
#
# Change the lines that have this value with your target list name id.
# p.prospect_list_id = '26ebae5a-e319-a188-6c46-4c43fc963021'

select c.id, c.modified_user_id, c.assigned_user_id, 
c.salutation, c.first_name, c.last_name, c.title, 
c.do_not_call, c.phone_home, c.phone_work, c.phone_fax, 
c.primary_address_street, c.primary_address_city, 
c.primary_address_state, c.primary_address_postalcode, 
c.primary_address_country, c.alt_address_street, 
c.alt_address_city, c.alt_address_state, c.id as contact_id, 
c.alt_address_postalcode, c.alt_address_country, 
c.assistant, c.assistant_phone, c.lead_source, 
c.portal_name, c.campaign_id, p.related_type, accounts.id as account_id, 
accounts.name as account_name, users.user_name as 
assigned_user_name, email_addresses.email_address email1 
from contacts c 
JOIN prospect_lists_prospects p ON c.id = p.related_id and 
p.prospect_list_id = '26ebae5a-e319-a188-6c46-4c43fc963021' 
LEFT JOIN users ON c.assigned_user_id=users.id 
LEFT JOIN accounts_contacts ON ( c.id=accounts_contacts.contact_id and (accounts_contacts.deleted is null or accounts_contacts.deleted = 0)) 
LEFT JOIN accounts ON accounts_contacts.account_id=accounts.id AND accounts.deleted=0 
LEFT JOIN email_addr_bean_rel on  email_addr_bean_rel.bean_id = c.id and email_addr_bean_rel.bean_module='Contacts' and email_addr_bean_rel.deleted=0 and email_addr_bean_rel.primary_address=1 
LEFT JOIN email_addresses on email_addresses.id = email_addr_bean_rel.email_address_id 

UNION 

select c.id, c.modified_user_id, c.assigned_user_id, 
c.salutation, c.first_name, c.last_name, c.title, 
c.do_not_call, c.phone_home, c.phone_work, c.phone_fax, 
c.primary_address_street, c.primary_address_city, 
c.primary_address_state, c.primary_address_postalcode, 
c.primary_address_country, c.alt_address_street, 
c.alt_address_city, c.alt_address_state, c.contact_id, 
c.alt_address_postalcode, c.alt_address_country, 
c.assistant, c.assistant_phone, c.lead_source, 
c.portal_name, c.campaign_id, p.related_type, c.account_id, 
c.account_name, users.user_name as 
assigned_user_name, email_addresses.email_address email1 
from leads c 
JOIN prospect_lists_prospects p ON c.id = p.related_id and 
p.prospect_list_id = '26ebae5a-e319-a188-6c46-4c43fc963021' 
LEFT JOIN users ON c.assigned_user_id=users.id 
LEFT JOIN email_addr_bean_rel on email_addr_bean_rel.bean_id = c.id  and email_addr_bean_rel.bean_module='Leads' and email_addr_bean_rel.deleted=0 and email_addr_bean_rel.primary_address=1 
LEFT JOIN email_addresses on email_addresses.id = email_addr_bean_rel.email_address_id 
